// SPDX-License-Identifier: ISC
// SPDX-FileCopyrightText: 2019 Mikko Murto <mikko.murto@gmail.com>

console.log('Where are we?');
