// SPDX-License-Identifier: MIT
// SPDX-FileCopyrightText: 2019 Mikko Murto <mikko.murto@gmail.com>

console.log('Where are we?');
